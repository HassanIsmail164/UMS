<?php
// controller
session_start();
require_once("../../View/Teacher/teacherHeader.php");
require_once("../../Model/DatabaseManager.php");
require_once("../../Model/teacher/modelTeacherClasses.php");
require_once("../../Model/teacher/modelClassDetails.php");
require_once("../../View/Teacher/teacherStudentList.php");
require_once("../../Model/student/modelStudentClasses.php");


// new object of the class    DatabaseManager
$Conn = new DatabaseManager();

$grade =$_POST['grade'];
$fileUpload = "Hassan";
$studentClassID = $_GET['studentClassID'];
$classID = $_GET['classID'];

$InsertDetails = new ClassesDetails($Conn);

$insertDetails = $InsertDetails->insertDetails( $studentClassID, $grade, $fileUpload);
header("Location:../../View/Teacher/teacherStudentList.php");
?>