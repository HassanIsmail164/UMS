<?php
// controller
session_start();

require_once("../../Model/DatabaseManager.php");
require_once("../../Model/teacher/modelTeacherClasses.php");

// new object of the class    DatabaseManager
$Conn = new DatabaseManager();


?>
