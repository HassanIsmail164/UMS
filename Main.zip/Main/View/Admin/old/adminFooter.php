</div>
<div id="footer">
        <p>&copy; Design by MTH Team</p>
    </div>
    <!-- end #footer -->
</body>

</html>