<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    }

require_once("teacherHeader.php");
require_once("../../Model/DatabaseManager.php");
require_once("../../Model/student/modelSemester.php");
require_once("../../Model/teacher/modelTeacherClasses.php");
require_once("../../Model/admin/modelSchedule.php");

// new object of the class DatabaseManager
$Conn = new DatabaseManager();

$classID = $_GET['classID'];

// new object of the class GetStudentClasses
$GetClassesStudent = new TeacherClasses($Conn);

$getClassesStudent = $GetClassesStudent->showClassesStudent($classID);

// condition to check if the user in loged in
if (isset($_SESSION['teacherID'])) {
?>
    <title>Class Details</title>
    <div class="header">

        <h2>Class Details :</h2><br>
        <form action="../../Controller/teacher/grade.php" method="POST">
            <table style="width: 100%" border="1" class="table-striped" cellpadding="7">
                <tr align="center" style="font-size: 20px">
                    <td><strong>IDs</strong> </td>
                    <td><strong>Names</strong></td>
                    <td><strong>Grades</strong> </td>
                    <td><strong>Documents</strong> </td>

                </tr>

                <?php
                for ($i = 0; $i < count($getClassesStudent); $i++) {
                ?>
                    <tr align="center">
                        <td><?php echo $getClassesStudent[$i]["studentID"]; ?></td>
                        <td><?php echo $getClassesStudent[$i]["Fname"] . " " . $getClassesStudent[$i]["Lname"]; ?></td>
                        <td><input type="number" name="grade"></td>
                        <td><input type="file" name="fileToUpload"></td>
                        
                    <?php
                }
                    ?>
            </table><br>
            <center><input class="btn btn-secondary" type="submit" value="Save"></center>
        </form>
    </div>


<?php require_once("teacherFooter.php");
} else {
    // if he/she is not logined, return to login page
    header("Location:../../index.php");
}
?>