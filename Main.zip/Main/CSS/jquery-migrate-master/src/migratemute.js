// Included only in the minified build, via Uglify2
// Only turn warnings off if not already overridden
if ( typeof jQuery.migrateMute === "undefined" ) {
	jQuery.migrateMute = true;
}
