<?php
// model
class StudentClassDetails
{

    private $dbConnection;

    function __construct($dbConnection)
    {
        $this->dbConnection = $dbConnection;
    }

    function showClassDetails($studentClassID)
    {
        //select query to check the login 
        $classesDetailsQuery = "SELECT  grade, document FROM class_details WHERE studentClassID = '$studentClassID' ";

        // result of the query set in variable login
        $ClassesDetails = $this->dbConnection->selectQuery($classesDetailsQuery);

        return $ClassesDetails;
    }
}
