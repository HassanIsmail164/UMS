<?php
// model
class ClassesDetails
{
    private $dbConnection;

    function __construct($dbConnection)
    {
        $this->dbConnection = $dbConnection;
    }

    function insertDetails($studentClassID, $grade,$file)
    {
        //INSERT  query to insert courses offered in studentClass table
        $insertDetailsQuery = "INSERT INTO classDetails (studentClassID, grade, document) VALUES ($studentClassID, $grade, $file)";

        // result of the query set in variable login
        $insertDetails = $this->dbConnection->executeQuery($insertDetailsQuery);

        return $insertDetails;
    }
}
